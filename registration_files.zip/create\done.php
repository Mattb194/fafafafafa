<?php 
session_start();

require('../includes/config.php');
require('../structure/database.php');
require('../structure/base.php');
require('../structure/user.php');
require('../structure/user.register.php');

$database = new database($db_host, $db_name, $db_user, $db_password);
$base = new base($database);
$user = new user($database);
$register = new user_register($database);

//preform basic checks before loading page
if($user->isLoggedIn()) $base->redirect('../index.php');
if(!isset($_SESSION['age']) || !isset($_SESSION['country']) || !isset($_SESSION['username']) || !isset($_SESSION['terms']) || !isset($_SESSION['password'])) $base->redirect('index.php');

$cookie = $register->generateCookie();

//create new account
$database->processQuery(
    "INSERT INTO `users`
        (`username`, `password`, `age`, `country`, `email`, `reg_date`, `acc_status`, `ip`, `lastpost`, `lastlogin`, `cookie`, `forum_mute`, `mute_time`, `updated`, `invited`, `lastbump`, `lastip`, `donator`, `signature`, `role_id`)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    array(
        $_SESSION['username'],
        $_SESSION['password'],
        $_SESSION['age'],
        $_SESSION['country'],
        'nope.avi',
        date('M-d-Y'),
        1,
        $_SERVER['REMOTE_ADDR'],
        0,
        0,
        $cookie,
        0,
        0,
        1,
        0,
        0,
        $_SERVER['REMOTE_ADDR'],
        0,
        '',
        1
    ),
    false
);

$username = $_SESSION['username'];
$register->clear();
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" href="../css/modern.css">
<meta charset="utf-8">
<meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<link rel="shortcut icon" href="../img/favicon.ico" />
<title><?php echo $data['wb_title']; ?></title>
<link href="../css/basic-3.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/register-1.css" rel="stylesheet" type="text/css" media="all">
<?php include('../includes/google_analytics.html'); ?>
<style type="text/css">
#emailSection, #ageSection, #usernameSection, #termsSection, #passwordSection {
        visibility: hidden;
}
</style>
<link rel="stylesheet" href="../css/gaming-theme.css">
<link rel="stylesheet" href="../css/esports-v3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
<div id="body">
<div style="text-align: center; background: none;">
        <div class="titleframe e">
                <b>Create a free account (New user)</b><br>
                <a href="../index.php">Main Menu</a>
        </div>
</div>
<br>

<div id="reg">
        <table cellspacing="0" cellpadding="0">
                <tbody><tr>
                        <td id="ageReg" class="box">&nbsp; Age and Location &nbsp;</td>
			<td id="usernameReg" class="box">&nbsp; Choose a Username &nbsp;</td>
			<td id="termsReg" class="cur">&nbsp; Terms and Conditions &nbsp;</td>
			<td id="passwordReg" class="box">&nbsp; Choose a Password &nbsp;</td>
			<td id="finishReg" class="box">&nbsp; Finish &nbsp;</td>
                </tr>
        </tbody></table>
</div>

<div class="frame wide_e">
<table width="100%">
<tbody>
<tr>
<td style="text-align: justify; vertical-align: top;">
Your account <b><?php echo $username; ?></b> has now been created with the password you have chosen. We recommend you make a note of it on a bit of paper and keep it somewhere really safe, in case you forget it.<br/><br/>
<center>Click below to go back to the website homepage:<br/><a href="../index.php">Home</a></center>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<?php include_once rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? '/var/www/html'), '/') . '/includes/site-footer.php'; ?>
</body></html>