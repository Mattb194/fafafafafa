<?php
declare(strict_types=1);

/**
 * RCS database migration runner.
 *
 * Migration files live in database/migrations and are applied in filename order.
 * Each successful migration is recorded in schema_migrations so it is only
 * applied once. Individual migrations should be written to be idempotent where
 * practical because an older installation may already contain part of a change.
 */
final class RcsMigrationRunner
{
    private const LOCK_NAME = 'rcs_schema_migrations';
    private const LOCK_TIMEOUT = 30;

    public static function run(PDO $pdo, string $migrationDir): void
    {
        if (!is_dir($migrationDir)) {
            return;
        }

        // The base schema is installed by database.sql. During the very first
        // seconds of a fresh Docker database it may not exist yet; simply retry
        // on the next request rather than breaking the site.
        if (!self::tableExists($pdo, 'users') || !self::tableExists($pdo, 'roles')) {
            return;
        }

        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `schema_migrations` (
                `migration` varchar(190) NOT NULL,
                `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`migration`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );

        $locked = (int)$pdo->query(
            "SELECT GET_LOCK(" . $pdo->quote(self::LOCK_NAME) . ", " . self::LOCK_TIMEOUT . ")"
        )->fetchColumn();

        if ($locked !== 1) {
            throw new RuntimeException('The database migration lock could not be acquired.');
        }

        try {
            $applied = $pdo->query("SELECT `migration` FROM `schema_migrations`")->fetchAll(PDO::FETCH_COLUMN);
            $applied = array_fill_keys(array_map('strval', $applied), true);

            $files = glob(rtrim($migrationDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '*.sql') ?: [];
            sort($files, SORT_NATURAL | SORT_FLAG_CASE);

            foreach ($files as $file) {
                $migration = basename($file, '.sql');
                if (isset($applied[$migration])) {
                    continue;
                }

                $sql = file_get_contents($file);
                if ($sql === false) {
                    throw new RuntimeException("Unable to read migration {$migration}.");
                }

                try {
                    foreach (self::splitSql($sql) as $statement) {
                        $pdo->exec($statement);
                    }

                    $stmt = $pdo->prepare(
                        "INSERT INTO `schema_migrations` (`migration`) VALUES (?)"
                    );
                    $stmt->execute([$migration]);
                } catch (Throwable $e) {
                    throw new RuntimeException(
                        "Database migration {$migration} failed: " . $e->getMessage(),
                        0,
                        $e
                    );
                }
            }
        } finally {
            $pdo->query(
                "SELECT RELEASE_LOCK(" . $pdo->quote(self::LOCK_NAME) . ")"
            );
        }
    }

    private static function tableExists(PDO $pdo, string $table): bool
    {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = ?"
        );
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /**
     * Split ordinary SQL migration files without breaking semicolons inside
     * quoted strings. Comments are removed first.
     *
     * The bundled migrations intentionally use ordinary DDL/DML rather than
     * stored procedures, so this keeps the runner small and portable.
     *
     * @return list<string>
     */
    private static function splitSql(string $sql): array
    {
        $sql = preg_replace('/^\xEF\xBB\xBF/', '', $sql) ?? $sql;
        $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
        $sql = preg_replace('/^\s*#.*$/m', '', $sql) ?? $sql;
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql) ?? $sql;

        $statements = [];
        $buffer = '';
        $quote = null;
        $length = strlen($sql);

        for ($i = 0; $i < $length; $i++) {
            $char = $sql[$i];

            if ($quote !== null) {
                $buffer .= $char;
                if ($char === '\\' && $i + 1 < $length) {
                    $buffer .= $sql[++$i];
                    continue;
                }
                if ($char === $quote) {
                    // SQL escapes single/double quotes by doubling them.
                    if ($i + 1 < $length && $sql[$i + 1] === $quote) {
                        $buffer .= $sql[++$i];
                    } else {
                        $quote = null;
                    }
                }
                continue;
            }

            if ($char === "'" || $char === '"') {
                $quote = $char;
                $buffer .= $char;
                continue;
            }

            if ($char === ';') {
                $statement = trim($buffer);
                if ($statement !== '') $statements[] = $statement;
                $buffer = '';
                continue;
            }

            $buffer .= $char;
        }

        $statement = trim($buffer);
        if ($statement !== '') $statements[] = $statement;

        return $statements;
    }
}
