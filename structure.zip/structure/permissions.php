<?php
declare(strict_types=1);

final class Permissions
{
    public const ALL = [
        'admin.access' => 'Access administration',
        'users.view' => 'View users',
        'users.edit' => 'Edit users',
        'users.rank' => 'Change user ranks',
        'users.ban' => 'Ban/unban users',
        'forums.moderate' => 'Moderate forums',
        'forums.manage' => 'Create/edit forums',
        'content.manage' => 'Manage news, stories and pages',
        'rules.manage' => 'Create, edit and publish community rules',
        'changelog.manage' => 'Manage the public changelog',
        'site.settings' => 'Change site settings',
        'reports.view' => 'View reports',
        'reports.resolve' => 'Resolve reports',
        'audit.view' => 'View administration audit log',
        'users.create' => 'Create member accounts',
        'users.username' => 'Change member usernames',
        'users.signature' => 'Manage member signatures',
        'users.badges' => 'Award and manage badges',
        'messages.system' => 'Send private messages from System',
        'messages.restrictions' => 'Manage private-message restrictions',
        'content.polls' => 'Create community polls',
        'content.uploads' => 'Manage screenshot uploads',
        'accounts.recovery' => 'Manage account recovery requests',
        'site.maintenance' => 'Toggle maintenance mode',
        'site.rules' => 'Manage community rules',
        'staff.altcheck' => 'Check alternate accounts',
        'staff.infractions' => 'Issue and review infractions',
        'staff.recentposts' => 'Review recent forum posts',
        'users.create' => 'Create member accounts',
        'users.username' => 'Change member usernames',
        'users.signature' => 'Manage member signatures',
        'users.badges' => 'Award and manage badges',
        'messages.system' => 'Send private messages from System',
        'messages.restrictions' => 'Manage private-message restrictions',
        'content.polls' => 'Create community polls',
        'content.uploads' => 'Manage screenshot uploads',
        'accounts.recovery' => 'Manage account recovery requests',
        'site.maintenance' => 'Toggle maintenance mode',
        'site.rules' => 'Manage community rules',
        'staff.altcheck' => 'Check alternate accounts',
        'staff.infractions' => 'Issue and review infractions',
        'staff.recentposts' => 'Review recent forum posts',
    ];

    public function __construct(private database $db) {}

    public function can(string $username, string $permission): bool
    {
        if (!isset(self::ALL[$permission])) return false;
        $row = $this->db->processQuery(
            "SELECT MAX(r.priority) AS priority, rp.permission_key
             FROM users u
             LEFT JOIN user_roles ur ON ur.user_id = u.id
             LEFT JOIN roles r ON r.id = ur.role_id
             LEFT JOIN role_permissions rp ON rp.role_id = r.id AND rp.permission_key = ?
             WHERE u.username = ?
               AND (ur.role_id IS NOT NULL OR u.role_id IS NOT NULL)
             GROUP BY rp.permission_key",
            [$permission, $username], true
        );
        return !empty($row) && ((int)($row[0]['priority'] ?? 0) > 0) && !empty($row[0]['permission_key']);
    }

    public function require(string $username, string $permission, string $redirect = '../index.php'): void
    {
        if (!$this->can($username, $permission)) {
            header('Location: '.$redirect, true, 302);
            exit;
        }
    }

    public function canAny(string $username, array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if ($this->can($username, (string)$permission)) return true;
        }
        return false;
    }

    public function requireAny(string $username, array $permissions, string $redirect = '../index.php'): void
    {
        if (!$this->canAny($username, $permissions)) {
            header('Location: '.$redirect, true, 302);
            exit;
        }
    }

    public function isProtected(string $target): bool
    {
        $row = $this->db->processQuery(
            "SELECT pa.user_id FROM protected_accounts pa INNER JOIN users u ON u.id=pa.user_id WHERE u.username=? LIMIT 1",
            [$target], true
        );
        return !empty($row);
    }

    public function canManageProtected(string $actor, string $target): bool
    {
        if (!$this->isProtected($target)) return true;
        $row = $this->db->processQuery(
            "SELECT 1
             FROM protected_accounts pa
             INNER JOIN users target ON target.id=pa.user_id
             INNER JOIN protected_account_managers pam ON pam.protected_user_id=pa.user_id
             INNER JOIN users manager ON manager.id=pam.manager_user_id
             WHERE target.username=? AND manager.username=? LIMIT 1",
            [$target, $actor], true
        );
        return !empty($row);
    }

    public function requireTargetAccess(string $actor, string $target, string $redirect = '../index.php'): void
    {
        if (!$this->canManageProtected($actor, $target)) {
            header('Location: '.$redirect, true, 302);
            exit;
        }
    }

    public function audit(string $username, string $action, ?string $target = null, ?string $details = null): void
    {
        $this->db->processQuery(
            "INSERT INTO admin_audit_log (username, action, target, details, ip, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
            [$username, $action, $target, $details, $_SERVER['REMOTE_ADDR'] ?? 'unknown'], false
        );
    }
}

