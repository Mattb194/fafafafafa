<?php
/** Send automated account events through Direct Private Messages. */
function rcs_send_system_private_message($database, int $recipientId, string $subject, string $body): bool {
    try {
        $sys = $database->processQuery("SELECT id FROM users WHERE username=? LIMIT 1", ['System'], true) ?? [];
        if (!$sys) $sys = $database->processQuery("SELECT id FROM users WHERE id=61 LIMIT 1", [], true) ?? [];
        if (!$sys || $recipientId < 1 || (int)$sys[0]['id'] === $recipientId) return false;
        $sid=(int)$sys[0]['id'];
        $recipient=$database->processQuery("SELECT id FROM users WHERE id=? AND acc_status<>0 LIMIT 1", [$recipientId], true) ?? [];
        if (!$recipient) return false;
        $conv=$database->processQuery("SELECT id FROM dm_conversations WHERE (user_one_id=? AND user_two_id=?) OR (user_one_id=? AND user_two_id=?) ORDER BY updated_at DESC LIMIT 1", [$sid,$recipientId,$recipientId,$sid], true) ?? [];
        if ($conv) $cid=(int)$conv[0]['id']; else {
            $database->processQuery("INSERT INTO dm_conversations (user_one_id,user_two_id,subject,created_at,updated_at) VALUES (?,?,?,NOW(),NOW())", [$sid,$recipientId,mb_substr(trim($subject) ?: 'Account notification',0,120)], false);
            $cid=(int)$database->getInsertId();
        }
        if ($cid<1) return false;
        $database->processQuery("INSERT INTO dm_messages (conversation_id,sender_id,body,created_at) VALUES (?,?,?,NOW())", [$cid,$sid,trim($body)], false);
        $database->processQuery("UPDATE dm_conversations SET updated_at=NOW() WHERE id=?", [$cid], false);
        return true;
    } catch (Throwable $e) { return false; }
}
