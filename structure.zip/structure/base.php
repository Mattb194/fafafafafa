<?php

 /*
 * @BASE
 * ~~~~~~~~~~~~
 * @FILE DESCRIPTION: includes basic functions that some pages use
 * @LAST MODIFIED: June 5, 2012
 */

class base
{
    private $database;
    
    /*
     * @METHOD  construct
     * @DESC    runs important functions/methods upon initiating
     */
    
    public function __construct(?database $database = null)
    {
        if(!is_null($database)) $this->database = $database;
    }
    
    /*
     * @METHOD  userCount
     * @DESC    # of users registered
     */
    
    public function userCount()
    {
        if($this->database == null)
        {
            die('Can\'t use userCount() without access to database class');
        }
        else
        {
            $this->database->processQuery("SELECT * FROM `users`", array(), false);
            return $this->database->getRowCount();
        }
    }
    
    /*
     * @METHOD  loadConig
     * @DESC    loads the config settings from the database table "config"
     */
    
    public function loadConfig()
    {
        if($this->database == null){
            die('BASE : loadConfig - Cannot load config without DB connection');
        }else{
            $returned = $this->database->processQuery("SELECT * FROM config", array(), true);
            
            return array('postcount' => $returned[0]['postcount'], 'floodlimit' => $returned[0]['floodlimit'], 'maintenance' => $returned[0]['maintenance'], 'reportforum' => $returned[0]['reportforum'], 'bbcode_members' => $returned[0]['bbcode_members'], 'play_url' => $returned[0]['play_url']);
        }
    }
    
    /*
     * @METHOD  redirect
     * @DESC    instead of writing the header function so many times,
     * @DESC    we'll just use this redirect function
     */
    
    public function redirect($url)
    {
        header('Location: '. $url);
        exit();
    }
    
    
    /*
     * @METHOD  getPageName
     * @DESC    returns the name of the page the viewer is on
     */
	
    public function getPageName()
    {
        $page = preg_replace('#\/(.+)\/#', '', $_SERVER['PHP_SELF']);
        $page = str_replace('/', null, $page);
        return $page;
    }
    
    /*
     * @METHOD  br2nl
     * @DESC    converts break tags to \n (new lines)
     */
    
    public function br2nl($string)
    {
        return str_replace('&lt;br /&gt;', '<br />', $string);
    }
    
    /*
     * @METHOD  remBr
	 * @DESC	get rid of <br /> (such as when you edit a post)
     */
    
    public function remBr($content)
    {
        return str_replace('<br />', null, $content);
    }
    
    /*
     * @METHOD  seconds_to_time
     * @DESC    converts an int (seconds) to a string, E.G:
     * @DESC    4 Days 3 Hours 26 Seconds
     */
    
    public function seconds_to_time($seconds)
    {
            if($seconds == 0) return 'Never.';
            
            //time units
            $units = array('day' => 86400, 'hour' => 3600, 'minute' => 60, 'second' => 1);
            $s = '';

            foreach($units as $name => $key)
            {
                    if($k = intval($seconds / $key))
                    {
                            ($k > 1) ? $s .= $k.' '.$name.'s ' : $s .= $k.' '.$name.' ';

                            //update seconds
                            $seconds -= $k*$key;
                    }
            }

            return $s;
    }
	
	/*
		@METHOD	writeToFile
		@DESC	Does what it says - writes to a file
	*/
    
    public function appendToFile($file, array $string)
    {
            $file_handle = fopen($file, 'a');
            
            foreach($string as $string_to_write)
            {
                fwrite($file_handle, '['. date('M-d-Y h:m:s') .'] '.$string_to_write."\n");
            }

            fclose($file_handle);
    }
    
    /*
     * @METHOD  shorten
     * @DESC    shortens the string to the length, then returns it
     * @PARAM   $cutoff  1 = return without words being cut-off
     */
    
    public function shorten($string, $length, $cutoff = false)
    {
        if(!$cutoff)
        {
            return substr($string, 0, (int) $length);
        }
        else
        {
            $string = substr($string, 0, (int) $length);
            return $string = substr($string, 0, strrpos($string, ' '));
        }
            
    }
    
    public function randomString($length)
    {
        $array = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7',
                       '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '!', '&', '^', '#', '@', 'a', 'b', 'c', 'd');
        
        $selected = '';
        
        for($x = 0; $x < (int) $length; $x++)
        {
            $selected .= time();
            $selected .= $array[rand(0,56)];
        }
        
        return substr(bin2hex(random_bytes((int)ceil($length / 2))), 0, (int)$length);
    }
    
    /*
     * @METHOD  addDecors
     * @DESC    for stories. changes [a] to a
     * @PARAM   base    the base url for images
     */
    
    public function addSpecials($content, $base)
    {
        //add decors
        $original = array('[a]', '[f]', '[i]', '[k]', '[l]', '[s]', '[t]', '[w]', '[y]');

        $decors = array('<img src="'.$base .'decor_a.gif" style="float:left;">', 
                            '<img src="'.$base .'decor_f.gif" style="float:left;">',
                            '<img src="'.$base .'decor_i.gif" style="float:left;">',
                            '<img src="'.$base .'decor_k.gif" style="float:left;">',
                            '<img src="'.$base .'decor_l.gif" style="float:left;">',
                            '<img src="'.$base .'decor_s.gif" style="float:left;">',
                            '<img src="'.$base .'decor_t.gif" style="float:left;">',
                            '<img src="'.$base .'decor_w.gif" style="float:left;">',
                            '<img src="'.$base .'decor_y.gif" style="float:left;">');
        
        $content = str_replace($original, $decors, $content);
        
        return $content;
    }
    
    /*
     * @METHOD  getNavBar
     * @DESC    get the navigation bar for the user
     */
    
    
    public function getNavBar($username, $path, $rank = null)
    {
        $root = trim((string)$path);
        // Config may provide a host-only base such as localhost:8080/.
        // Without a scheme, browsers treat that as a custom protocol and links won't navigate.
        if ($root !== '' && !preg_match('~^https?://~i', $root) && $root[0] !== '/') {
            $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ? 'https' : 'http';
            $root = $scheme . '://' . $root;
        }
        $root = rtrim($root, '/') . '/';
        $loggedIn = !empty($username);
        $siteData = $GLOBALS['data'] ?? array();
        $brand = htmlspecialchars((string)($siteData['wb_abbr'] ?? 'RCS'), ENT_QUOTES, 'UTF-8');
        $rank = (int)$rank;
        $current = strtolower((string)($_SERVER['PHP_SELF'] ?? ''));
        $active = 'home';
        if (strpos($current, '/forums/') !== false) $active = 'forums';
        elseif (strpos($current, '/news/') !== false) $active = 'news';
        elseif (strpos($current, '/stories/') !== false) $active = 'stories';
        elseif (strpos($current, '/page.php') !== false) $active = 'pages';
        elseif (strpos($current, '/rules.php') !== false) $active = 'rules';
        ?>
        <?php $isStaffPanel = (strpos($current, '/admin/') !== false || strpos($current, '/mod/fmod/') !== false); ?>
        <header class="rcs-topbar<?php echo $isStaffPanel ? '' : ' rcs-topbar--public'; ?>">
            <div class="rcs-topbar-inner">
                <a class="rcs-brand" href="<?php echo htmlspecialchars($root . 'index.php', ENT_QUOTES, 'UTF-8'); ?>">
                    <span class="brand-mark"><i class="fa-solid fa-dragon" aria-hidden="true"></i></span>
                    <span><?php echo $brand; ?><small>COMMUNITY</small></span>
                </a>
                <nav class="rcs-nav" aria-label="Main navigation">
                    <a class="<?php echo $active === 'home' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'index.php', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-house" aria-hidden="true"></i> Home</a>
                    <a class="<?php echo $active === 'forums' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'forums/', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-regular fa-comments" aria-hidden="true"></i> Forums</a>
                    <a class="<?php echo $active === 'members' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'forums/members.php', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-users" aria-hidden="true"></i> Members</a>
                    <a class="<?php echo $active === 'news' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'news/', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-regular fa-newspaper" aria-hidden="true"></i> News</a>
                    <a class="<?php echo $active === 'stories' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'stories/', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-book-open" aria-hidden="true"></i> Stories</a>
                    <a class="<?php echo $active === 'pages' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'page.php', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-regular fa-file-lines" aria-hidden="true"></i> Pages</a>
                    <a class="<?php echo $active === 'rules' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($root . 'rules.php', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-scale-balanced" aria-hidden="true"></i> Rules</a>
                    <?php if ($loggedIn && $rank >= 2): ?><a href="<?php echo htmlspecialchars($root . 'mod/fmod/', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Moderator Panel</a><?php endif; ?>
                    <?php if ($loggedIn && $rank >= 4): ?><a href="<?php echo htmlspecialchars($root . 'admin/dashboard.php', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-screwdriver-wrench" aria-hidden="true"></i> Admin Panel</a><?php endif; ?>
                </nav>
                <form class="rcs-global-search" action="<?php echo htmlspecialchars($root . 'forums/search.php', ENT_QUOTES, 'UTF-8'); ?>" method="post" role="search">
                    <input type="text" name="keywords" maxlength="30" placeholder="Search forums..." aria-label="Search forums">
                    <input type="hidden" name="forum" value="all">
                    <button type="submit" aria-label="Search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></button>
                </form>
                <div class="rcs-spacer"></div>
                <div class="rcs-user">
                    <?php if ($loggedIn): ?>
                        <a href="<?php echo htmlspecialchars($root . 'forums/profile.php?user=' . rawurlencode((string)$username), ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-regular fa-user" aria-hidden="true"></i> <?php echo htmlspecialchars((string)$username, ENT_QUOTES, 'UTF-8'); ?></a>
                        <a class="topbar-action" href="<?php echo htmlspecialchars($root . 'msgcenter/', ENT_QUOTES, 'UTF-8'); ?>" aria-label="Message Center"><i class="fa-regular fa-envelope" aria-hidden="true"></i> Messages</a>
                        <a class="topbar-action" href="<?php echo htmlspecialchars($root . 'logout.php', ENT_QUOTES, 'UTF-8'); ?>">Logout</a>
                    <?php else: ?>
                        <a class="topbar-action" href="<?php echo htmlspecialchars($root . 'login.php', ENT_QUOTES, 'UTF-8'); ?>">Login</a>
                        <a class="topbar-register" href="<?php echo htmlspecialchars($root . 'create/', ENT_QUOTES, 'UTF-8'); ?>"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </header>
        <?php
    }

}
?>