<?php
/*
 * @FORUM:INDEX
 * ~~~~~~~~~~~~
 * @FILE DESCRIPTION: the index of the forums
 * @LAST MODIFIED: June 7, 2012
 */

class forum_index extends forum
{
    public function retrieveCategories($rank)
    {
        return ($rank > 2) ? $this->database->processQuery("SELECT `title`,`id`,`type`,`icon_id` FROM `cats` ORDER BY `pos`", array(), true) : $this->database->processQuery("SELECT `title`,`id`,`type`,`icon_id` FROM `cats` WHERE `type` <> 1 ORDER BY `pos`", array(), true);
    }
    
    public function getCategoryIcon($iconId)
    {
        $icons = [
            1 => 'fa-gamepad', 2 => 'fa-user-shield', 3 => 'fa-comments',
            4 => 'fa-trophy', 5 => 'fa-newspaper', 6 => 'fa-users',
            7 => 'fa-life-ring', 8 => 'fa-star', 9 => 'fa-lock'
        ];
        $iconId = (int)$iconId;
        $iconClass = $icons[$iconId] ?? $icons[1];
        return '<i class="category-icon fa-solid ' . $iconClass . '" aria-hidden="true"></i>';
    }
    
    /*
     * @METHOD  retrieveSubForums
     * @DESC    retrieves all the forums of a specific category and returns them 
     * @DESC    as an array (pretty much same as retrieveCategories)
     */
    
    public function retrieveSubForums($parent)
    {
        return (isset($_COOKIE['user']))? $this->database->processQuery("SELECT `id`,`title`,`description`,`icon`,`type` FROM `forums` WHERE `parent` = ? ORDER BY `pos`", array($parent), true) : $this->database->processQuery("SELECT `id`,`title`,`description`,`icon`,`type` FROM `forums` WHERE `parent` = ? AND `type` <> 6 ORDER BY `pos`", array($parent), true);
    }
    
    /*
     * @METHOD  retrieveFStatistics
     * @DESC    retrieves the statistis for the specified forum
     * @DESC    which is currently post count and thread count
     */
    
    public function retrieveFStatistics($id)
{
    $statistics = array();
    $statistics['thread_count'] = 0;
    $statistics['post_count'] = 0;
    $statistics['last_post'] = null;

    // Get all the threads under the specified forum
    $threads = $this->database->processQuery(
        "SELECT `id` FROM `threads` WHERE `parent` = ? ORDER BY `id`",
        array($id),
        true
    );

    // Update thread count
    $statistics['thread_count'] = $this->database->getRowCount();

    // Get the forum's last post
    $last_post = $this->database->processQuery(
        "SELECT `lastpost` FROM `threads` WHERE `parent` = ? ORDER BY `id` DESC LIMIT 1",
        array($id),
        true
    );

    if (isset($last_post[0]['lastpost'])) {
        $statistics['last_post'] = $last_post[0]['lastpost'];
    }

    // Get post count
    foreach ($threads as $thread) {
        $this->database->processQuery(
            "SELECT * FROM `posts` WHERE `thread` = ?",
            array($thread['id']),
            true
        );

        $statistics['post_count'] += $this->database->getRowCount();
    }

        return $statistics;
}
}



