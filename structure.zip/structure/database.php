<?php
declare(strict_types=1);

class database
{
    private PDO $dbc;
    private int $row_count = 0;
    private string $insertId = '0';

    public function __construct(
        string $db_host,
        string $db_name,
        string $db_user,
        string $db_password,
        string $db_port = '3306'
    ) {
        $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";

        $this->dbc = new PDO($dsn, $db_user, $db_password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);

        require_once __DIR__ . '/migrations.php';
        RcsMigrationRunner::run($this->dbc, dirname(__DIR__) . '/database/migrations');

        $this->isMaintenance();
    }

    public function setAttribute(int $attribute, mixed $value): void
    {
        $this->dbc->setAttribute($attribute, $value);
    }

    public function processQuery(string $query, array $binds = [], bool $fetch = false): ?array
    {
        $statement = $this->dbc->prepare($query);
        $statement->execute($binds);

        $this->insertId = (string)$this->dbc->lastInsertId();
        $this->row_count = $statement->rowCount();

        return $fetch ? $statement->fetchAll() : null;
    }

    public function getRowCount(): int { return $this->row_count; }
    public function resetRowCount(): void { $this->row_count = 0; }
    public function getInsertId(): string { return $this->insertId; }
    public function close_connection(): void {}
    public function getDBStatus(): bool { return isset($this->dbc); }

    private function isMaintenance(bool $return = false): bool
    {
        // The config table is created during setup. Do not block the installer if it isn't there yet.
        try {
            $maintenance = $this->processQuery(
                "SELECT `maintenance` FROM `config` LIMIT 1",
                [],
                true
            );
        } catch (Throwable) {
            return false;
        }

        $enabled = !empty($maintenance[0]['maintenance']);

        if ($return) return $enabled;
        // Login must always remain available during maintenance so administrators can
        // authenticate and regain access to the site. Non-admin users are redirected
        // to the maintenance screen after login as normal.
        if (!$enabled || basename($_SERVER['PHP_SELF'] ?? '') === 'login.php') return false;

        $cookie = ($_COOKIE['user'] ?? '') ?? null;
        if (!$cookie) {
            header('Location: /maintenance.php', true, 302);
            exit;
        }

        $user = $this->processQuery(
            "SELECT `acc_status` FROM `users` WHERE `cookie` = ? LIMIT 1",
            [$cookie],
            true
        );

        if (!$user || (int)$user[0]['acc_status'] < 4) {
            header('Location: /maintenance.php', true, 302);
            exit;
        }

        return false;
    }
}
